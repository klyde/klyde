Minicorp WP - Readme

To properly install and use the theme, please open and read the documentation in "_Documentation" folder of the Zip file you have purchased from Themeforest.net.

IshYoBoy.com