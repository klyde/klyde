<input type="checkbox" name="<?php echo $id?>" id="<?php echo $id?>" <?php checked($value, 'true')?> value="true" />
